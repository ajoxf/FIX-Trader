# Host FIX-Trader on another Windows machine

This deployment archive contains the application, a safe `.env.example`, and a UAT venue configuration template based on this project's FIX setup. It deliberately excludes the real `.env`, live FIX sequence/session stores, databases, logs, cached state, and local account/instrument selections. The archive alone cannot authenticate or connect; set the TT passwords on the target host.

## 1. Prepare the target machine

1. Unzip `FIX-Trader-TT-UAT-Deploy.zip` into a folder such as `C:\FIX-Trader`.
2. Install Python 3.9 or newer. Open PowerShell in the extracted folder.
3. Create an isolated Python environment and install the packages:

   ```powershell
   py -3 -m venv .venv
   .\.venv\Scripts\Activate.ps1
   python -m pip install --upgrade pip
   python -m pip install -r requirements.txt
   ```

4. Copy the template to `.env` and enter the target account's TT UAT passwords for the listed variable names. Do not send `.env` in an unencrypted zip, email, chat, or source control. Prefer entering the values directly on the target machine. If you must transfer it, use a trusted encrypted channel such as OpenSSH `scp`, then restrict the file ACL and remove temporary copies.

   ```powershell
   Copy-Item .env.example .env
   notepad .env
   ```

5. Review `config.tt-uat.json` and confirm the UAT session identifiers and endpoints match TT provisioning. Configure account and contracts in the Exchanges/Instruments UI as appropriate. UAT and PROD must remain separate. Do not change sequence-reset behavior to work around a mismatch.

## 2. Network and clock

Allow outbound TCP from this host to the TT UAT Order Routing endpoint on port 11502 and Market Data endpoint on port 11503. The target machine may also need TT's network/VPN or source-IP allowlisting. Verify Windows time synchronization before logon. A successful TCP test does not prove FIX Logon succeeded.

## 3. Start and verify

First ensure the old machine has stopped its FIX process and no other application is logged on with these CompIDs. Never run both machines against the same sessions at once. If TT reports a sequence mismatch, stop retrying; reconcile the order session and sequence state with TT before reconnecting. The bundle does not carry the old host's sequence store.

Run the FIX-mode app (this does not arm the algorithm):

```powershell
.\.venv\Scripts\Activate.ps1
python start.py --fix --no-browser --config config.tt-uat.json --status status.tt-uat.json --commands commands.tt-uat.jsonl --results results.tt-uat.json --port 8000
```

Open `http://127.0.0.1:8000/connection` on the target machine. Confirm both Order Routing and Market Data show logged on, then verify live bid/ask updates on a permitted instrument. Keep the algo/master switches off. Automated algo execution and full account/order-position recovery are not complete in this build; a live FIX session does not mean algo orders can be safely sent.

The app binds to `127.0.0.1` by default. For remote use, connect to the host using Remote Desktop or a VPN. Do not expose the app directly to the public internet; it does not provide user authentication.

## 4. Secrets and state

Keep `.env`, `runtime/`, `logs/`, `*.db`, and status/command/result files private on the host. Back up required audit and book records according to your policy. This deployment zip intentionally starts with fresh local runtime state; it is not a migration of an active order book or FIX sequence state.
